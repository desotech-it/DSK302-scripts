#!/bin/bash
export NUMBERFILE=01
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl delete ns trouble01 >>$LOGFILE 2>&1
kubectl delete ns trouble02 >>$LOGFILE 2>&1
kubectl delete ns trouble03 >>$LOGFILE 2>&1
kubectl delete ns trouble04 >>$LOGFILE 2>&1
kubectl taint nodes worker01 worker=desotech:NoSchedule- >> $LOGFILE 2>&1
kubectl taint nodes worker02 worker=desotech:NoSchedule- >> $LOGFILE 2>&1
kubectl taint nodes worker03 worker=desotech:NoSchedule- >> $LOGFILE 2>&1
kubectl taint nodes worker04 worker=desotech:NoSchedule- >> $LOGFILE 2>&1
ssh worker04 >> $LOGFILE 2>&1 << ENDSSH
rm -f desotech.txt
ENDSSH

rm -f /home/student/opa-trouble01.yaml
rm -f /home/student/ubu-trouble02.yaml
rm -f /home/student/httpd-trouble02.yaml
rm -f /home/student/labs-trouble02.yaml
rm -f /home/student/deploy-trouble03.yaml
rm -f /home/student/deploy-trouble04.yaml