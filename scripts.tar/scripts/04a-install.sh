#!/bin/bash
export NUMBERFILE=04a
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble09 >> $LOGFILE 2>&1
cat >> $LOGFILE 2>&1 <<EOF >>/home/student/dsutils-trouble09.yaml
apiVersion: v1
kind: Pod
metadata:
  name: dsutils
  namespace: trouble09
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: desotech
  restartPolicy: Always
EOF

kubectl apply -f /home/student/dsutils-trouble09.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/dskdeso-trouble09.yaml
apiVersion: v1
kind: Pod
metadata:
  name: dskdeso
  namespace: trouble09
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: dskdeso
  restartPolicy: Always
EOF

kubectl apply -f /home/student/dskdeso-trouble09.yaml >> $LOGFILE 2>&1

ssh master01 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
cd /etc/kubernetes/manifests/
mv kube-apiserver.yaml ../
ENDSSH
