#!/bin/bash
export NUMBERFILE=03
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl delete pod pod-with-trouble -n trouble08 >> $LOGFILE 2>&1
kubectl delete pvc pvc-trouble -n trouble08 >> $LOGFILE 2>&1
kubectl delete ns trouble08 >> $LOGFILE 2>&1
rm -f /home/student/pod-trouble08.yaml >> $LOGFILE 2>&1
rm -f /home/student/pvc-trouble08.yaml >> $LOGFILE 2>&1
rm -f /home/student/pv-trouble08.yaml >> $LOGFILE 2>&1