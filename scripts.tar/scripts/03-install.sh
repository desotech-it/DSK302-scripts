#!/bin/bash
export NUMBERFILE=03
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble08 >> $LOGFILE 2>&1
cat >> $LOGFILE 2>&1 <<EOF >>/home/student/pv-trouble08.yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-trouble
  namespace: trouble08
  labels:
    type: local
spec:
  storageClassName: ""
  capacity:
    storage: 3Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/mnt/data"
EOF

kubectl apply -f /home/student/pv-trouble08.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/pvc-trouble08.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc-trouble
  namespace: trouble08
spec:
  storageClassName: ""
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
EOF

kubectl apply -f /home/student/pvc-trouble08.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/pod-trouble08.yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-with-trouble
  namespace: trouble08
spec:
  nodeSelector:
    kubernetes.io/hostname: worker01
  volumes:
    - name: pv-storage
      persistentVolumeClaim:
        claimName: pvc-trouble
  containers:
    - name: dsutils
      image: r.deso.tech/dsk/dsutils
      volumeMounts:
        - mountPath: "/test"
          name: pv-storage
EOF

kubectl apply -f /home/student/pod-trouble08.yaml >> $LOGFILE 2>&1

kubectl delete pv pv-trouble &>> $LOGFILE 2>&1
