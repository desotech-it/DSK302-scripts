#!/bin/bash
export NUMBERFILE=04b
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble10 >> $LOGFILE 2>&1
cat >> $LOGFILE 2>&1 <<EOF >>/home/student/dsutils-trouble10.yaml
apiVersion: v1
kind: Pod
metadata:
  name: dsutils
  namespace: trouble10
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: desotech
  restartPolicy: Always
EOF

kubectl apply -f /home/student/dsutils-trouble10.yaml >> $LOGFILE 2>&1

ssh master01 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
cd /etc/kubernetes/manifests/
mv kube-scheduler.yaml ../
ENDSSH

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble10.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: deploy-10
  namespace: trouble10
spec:
  replicas: 1
  selector:
    matchLabels:
      app: whoami
  template:
    metadata:
      labels:
        app: whoami
    spec:
      containers:
      - name: whoami-deso
        image: r.deso.tech/whoami/whoami:latest
        ports:
        - containerPort: 80
EOF

kubectl apply -f /home/student/deploy-trouble10.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deso10-trouble10.yaml
apiVersion: v1
kind: Pod
metadata:
  name: deso10
  namespace: trouble10
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: deso
  restartPolicy: Always
EOF

kubectl apply -f /home/student/deso10-trouble10.yaml >> $LOGFILE 2>&1