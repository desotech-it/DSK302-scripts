#!/bin/bash
export NUMBERFILE=04d
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble12 >> $LOGFILE 2>&1
cat >> $LOGFILE 2>&1 <<EOF >>/home/student/dsutils-trouble12.yaml
apiVersion: v1
kind: Pod
metadata:
  name: dsutils
  namespace: trouble12
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: desotech
  restartPolicy: Always
EOF

kubectl apply -f /home/student/dsutils-trouble12.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble12.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: destination
  namespace: trouble12
spec:
  replicas: 1
  selector:
    matchLabels:
      app: destination
  template:
    metadata:
      labels:
        app: destination
    spec:
      containers:
      - name: destination01
        image: r.deso.tech/whoami/whoami:latest
        ports:
        - containerPort: 80
EOF

kubectl apply -f /home/student/deploy-trouble12.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/srv-trouble12.yaml
apiVersion: v1
kind: Service
metadata:
  creationTimestamp: null
  name: destination
  namespace: trouble12
spec:
  ports:
  - port: 80
    protocol: TCP
    targetPort: 80
  selector:
    app: destination
  type: LoadBalancer
status:
  loadBalancer: {}
EOF

kubectl apply -f /home/student/srv-trouble12.yaml >> $LOGFILE 2>&1

kubectl patch daemonset kube-proxy -n kube-system -p '{"spec": {"template": {"spec": {"nodeSelector": {"kubernetes.io/os": "disable"}}}}}' >> $LOGFILE 2>&1