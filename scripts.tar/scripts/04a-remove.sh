#!/bin/bash
export NUMBERFILE=04a
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
ssh master01 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
cd /etc/kubernetes/manifests/
mv ../kube-apiserver.yaml .
ENDSSH
kubectl delete ns trouble09 >> $LOGFILE 2>&1
rm -f /home/student/dskdeso-trouble09.yaml >> $LOGFILE 2>&1
rm -f /home/student/dsutils-trouble09.yaml >> $LOGFILE 2>&1