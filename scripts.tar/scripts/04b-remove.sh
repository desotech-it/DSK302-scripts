#!/bin/bash
export NUMBERFILE=04b
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
ssh master01 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
cd /etc/kubernetes/manifests/
mv ../kube-scheduler.yaml .
ENDSSH
kubectl delete ns trouble10 >> $LOGFILE 2>&1
rm -f /home/student/dsutils-trouble10.yaml >> $LOGFILE 2>&1
rm -f /home/student/deploy-trouble10.yaml >> $LOGFILE 2>&1
rm -f /home/student/deso10-trouble10.yaml >> $LOGFILE 2>&1