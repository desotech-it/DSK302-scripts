#!/bin/bash
export NUMBERFILE=04c
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
ssh master01 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
cd /etc/kubernetes/manifests/
mv ../kube-controller-manager.yaml .
ENDSSH
kubectl delete ns trouble11 >> $LOGFILE 2>&1
rm -f /home/student/deploy-trouble11.yaml >> $LOGFILE 2>&1