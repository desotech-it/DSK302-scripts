#!/bin/bash
export NUMBERFILE=04c
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble11 >> $LOGFILE 2>&1
cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble11.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: deploy-whoami
  namespace: trouble11
spec:
  replicas: 1
  selector:
    matchLabels:
      app: whoami
  template:
    metadata:
      labels:
        app: whoami
    spec:
      containers:
      - name: whoami-deso
        image: r.deso.tech/whoami/whoami:latest
        ports:
        - containerPort: 80
EOF

kubectl apply -f /home/student/deploy-trouble11.yaml >> $LOGFILE 2>&1

ssh master01 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
cd /etc/kubernetes/manifests/
mv kube-controller-manager.yaml ../
ENDSSH
kubectl scale deployment/deploy-whoami -n trouble11 --replicas=10 >> $LOGFILE 2>&1