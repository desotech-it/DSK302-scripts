#!/bin/bash
export NUMBERFILE=04e
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl delete ns trouble13 >> $LOGFILE 2>&1
ssh worker03 >> $LOGFILE 2>&1  <<ENDSSH
sudo -i
systemctl start kubelet
ENDSSH