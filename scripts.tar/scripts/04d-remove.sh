#!/bin/bash
export NUMBERFILE=04d
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl patch daemonset kube-proxy -n kube-system -p '{"spec": {"template": {"spec": {"nodeSelector": {"kubernetes.io/os": "linux"}}}}}' >> $LOGFILE 2>&1
kubectl delete ns trouble12 >> $LOGFILE 2>&1
rm -f /home/student/dsutils-trouble12.yaml >> $LOGFILE 2>&1
rm -f /home/student/deploy-trouble12.yaml >> $LOGFILE 2>&1
rm -f /home/student/srv-trouble12.yaml >> $LOGFILE 2>&1