#!/bin/bash
export NUMBERFILE=01
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble01 >> $LOGFILE 2>&1
kubectl create ns trouble02 >> $LOGFILE 2>&1
kubectl create ns trouble03 >> $LOGFILE 2>&1
kubectl create ns trouble04 >> $LOGFILE 2>&1
kubectl taint nodes worker01 worker=desotech:NoSchedule >> $LOGFILE 2>&1
kubectl taint nodes worker02 worker=desotech:NoSchedule >> $LOGFILE 2>&1
kubectl taint nodes worker03 worker=desotech:NoSchedule >> $LOGFILE 2>&1
kubectl taint nodes worker04 worker=desotech:NoSchedule >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1  <<EOF >>/home/student/opa-trouble01.yaml
apiVersion: v1
kind: Pod
metadata:
  name: opa
  namespace: trouble01
spec:
  containers:
    - name: dsutils
      image: r.deso.tech/dsk/dsutils:latest
      livenessProbe:
        httpGet:
          path: /healthz
          port: 80
      readinessProbe:
        httpGet:
          path: /readiness
          port: 80
      resources:
        limits:
          cpu: "300m"
          memory: "1Mi"
      command: ["/usr/bin/stress"]
      args: ["--verbose","--vm","2","--vm-bytes","1G","--timeout","120s"]
  tolerations:
  - key: "worker"
    operator: "Equal"
    value: "desotech"
    effect: "NoSchedule"
  nodeSelector:
    kubernetes.io/hostname: worker01
EOF

kubectl apply -f /home/student/opa-trouble01.yaml >> $LOGFILE 2>&1 

cat >> $LOGFILE 2>&1  <<EOF >>/home/student/httpd-trouble02.yaml
apiVersion: v1
kind: Pod
metadata:
  name: httpd
  namespace: trouble02
spec:
  containers:
    - name: httpd
      image: r.deso.tech/dockerhub/library/httpd
      imagePullPolicy: Never
  tolerations:
   - key: "worker"
     operator: "Equal"
     value: "desotech"
     effect: "NoSchedule"
  nodeSelector:
    kubernetes.io/hostname: worker02
EOF

kubectl apply -f /home/student/httpd-trouble02.yaml >> $LOGFILE 2>&1 


cat >> $LOGFILE 2>&1  <<EOF >>/home/student/labs-trouble02.yaml
apiVersion: v1
kind: Pod
metadata:
  name: labs
  namespace: trouble02
spec:
  containers:
    - name: labs
      image: r.deso.tech/whoami/NicolaMarcoDecandia
  tolerations:
   - key: "worker"
     operator: "Equal"
     value: "desotech"
     effect: "NoSchedule"
  nodeSelector:
    kubernetes.io/hostname: worker02
EOF

kubectl apply -f /home/student/labs-trouble02.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/ubu-trouble02.yaml
apiVersion: v1
kind: Pod
metadata:
  name: ubu
  namespace: trouble02
spec:
  containers:
    - name: ubu
      image: r.deso.tech/dockerhub/library/ubuntu:latest
  tolerations:
   - key: "worker"
     operator: "Equal"
     value: "desotech"
     effect: "NoSchedule"
  nodeSelector:
    kubernetes.io/hostname: worker02
EOF

kubectl apply -f /home/student/ubu-trouble02.yaml >> $LOGFILE 2>&1 

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble03.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: deployment-test
  namespace: trouble03
spec:
  replicas: 111
  selector:
    matchLabels:
      app: deployment-rs
  template:
    metadata:
      labels:
        app: deployment-rs
    spec:
      containers:
      - name: container01
        image: r.deso.tech/dockerhub/library/nginx
        ports:
        - containerPort: 80
      tolerations:
      - key: "worker"
        operator: "Equal"
        value: "desotech"
        effect: "NoSchedule"
      nodeSelector:
        kubernetes.io/hostname: worker03
EOF

kubectl apply -f /home/student/deploy-trouble03.yaml >> $LOGFILE 2>&1

ssh worker04 >> $LOGFILE 2>&1  <<ENDSSH
fallocate -l 25G desotech.txt
ENDSSH

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble04.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: deployment-4
  namespace: trouble04
spec:
  replicas: 10
  selector:
    matchLabels:
      app: deployment-4-rs
  template:
    metadata:
      labels:
        app: deployment-4-rs
        environment: dev
    spec:
      containers:
      - name: nginx-trouble
        image: r.deso.tech/dockerhub/library/nginx
        ports:
        - containerPort: 80
      tolerations:
      - key: "worker"
        operator: "Equal"
        value: "desotech"
        effect: "NoSchedule"
      nodeSelector:
        kubernetes.io/hostname: worker04
EOF

kubectl apply -f /home/student/deploy-trouble04.yaml >> $LOGFILE 2>&1