rm -rf *.x.c
rm -rf *.x
rm -rf Dsk302-public/*
rm -rf *.log
shc -f 01-install.sh -o Dsk302-public/01-install
shc -f 01-remove.sh -o Dsk302-public/01-remove
shc -f 02-install.sh -o Dsk302-public/02-install
shc -f 02-remove.sh -o Dsk302-public/02-remove
shc -f 03-install.sh -o Dsk302-public/03-install
shc -f 03-remove.sh -o Dsk302-public/03-remove
shc -f 04a-install.sh -o Dsk302-public/04a-install
shc -f 04a-remove.sh -o Dsk302-public/04a-remove
shc -f 04b-install.sh -o Dsk302-public/04b-install
shc -f 04b-remove.sh -o Dsk302-public/04b-remove
shc -f 04c-install.sh -o Dsk302-public/04c-install
shc -f 04c-remove.sh -o Dsk302-public/04c-remove
shc -f 04d-install.sh -o Dsk302-public/04d-install
shc -f 04d-remove.sh -o Dsk302-public/04d-remove
shc -f 04e-install.sh -o Dsk302-public/04e-install
shc -f 04e-remove.sh -o Dsk302-public/04e-remove
rm -rf *.x.c


