#!/bin/bash
export NUMBERFILE=02
export NAMEFILE=remove
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl delete ns trouble05 >> $LOGFILE 2>&1
kubectl delete ns trouble06 >> $LOGFILE 2>&1
kubectl delete ns trouble07 >> $LOGFILE 2>&1
rm -f /home/student/deploy-trouble05.yaml >> $LOGFILE 2>&1
rm -f /home/student/srv-trouble05.yaml >> $LOGFILE 2>&1
rm -f /home/student/dsutils-2-trouble06.yaml >> $LOGFILE 2>&1
rm -f /home/student/dsutils-1-trouble06.yaml >> $LOGFILE 2>&1
rm -f /home/student/deploy-trouble06.yaml >> $LOGFILE 2>&1
rm -f /home/student/srv-trouble06.yaml >> $LOGFILE 2>&1
rm -f /home/student/deploy-trouble07.yaml >> $LOGFILE 2>&1
rm -f /home/student/srv-trouble07.yaml >> $LOGFILE 2>&1
rm -f /home/student/policy-trouble07.yaml >> $LOGFILE 2>&1
rm -f /home/student/origin-trouble07.yaml >> $LOGFILE 2>&1
rm -f /home/student/origin2-trouble07.yaml >> $LOGFILE 2>&1