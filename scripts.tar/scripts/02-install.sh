#!/bin/bash
export NUMBERFILE=02
export NAMEFILE=install
export COMPLETEFILE=$NUMBERFILE-$NAMEFILE
export LOGFILE=$COMPLETEFILE.log
export FILESH=$COMPLETEFILE.sh
touch $LOGFILE >> $LOGFILE 2>&1
kubectl create ns trouble05 >> $LOGFILE 2>&1
kubectl create ns trouble06 >> $LOGFILE 2>&1
kubectl create ns trouble07 >> $LOGFILE 2>&1
cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble05.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: deployment-05
  namespace: trouble05
spec:
  replicas: 3
  selector:
    matchLabels:
      app: deployment-rs
  template:
    metadata:
      labels:
        app: deployment-rs
    spec:
      containers:
      - name: desotech-pod
        image: r.deso.tech/dockerhub/library/nginx
        ports:
        - containerPort: 80
EOF

kubectl apply -f /home/student/deploy-trouble05.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/srv-trouble05.yaml
apiVersion: v1
kind: Service
metadata:
  creationTimestamp: null
  name: deployment-05
  namespace: trouble05
spec:
  ports:
  - port: 80
    protocol: TCP
    targetPort: 808
  selector:
    app: deployment-rs
  type: LoadBalancer
status:
  loadBalancer: {}
EOF

kubectl apply -f /home/student/srv-trouble05.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/dsutils-2-trouble06.yaml
apiVersion: v1
kind: Pod
metadata:
  name: dsutils-2
  namespace: trouble06
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: desotech-2
  restartPolicy: Always
  dnsPolicy: Default
EOF

kubectl apply -f /home/student/dsutils-2-trouble06.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/dsutils-1-trouble06.yaml
apiVersion: v1
kind: Pod
metadata:
  name: dsutils-1
  namespace: trouble06
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: desotech-1
  restartPolicy: Always
EOF

kubectl apply -f /home/student/dsutils-1-trouble06.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble06.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: destination
  namespace: trouble06
spec:
  replicas: 1
  selector:
    matchLabels:
      app: destination
  template:
    metadata:
      labels:
        app: destination
    spec:
      containers:
      - name: destination01
        image: r.deso.tech/whoami/whoami:latest
        ports:
        - containerPort: 80
EOF

kubectl apply -f /home/student/deploy-trouble06.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/srv-trouble06.yaml
apiVersion: v1
kind: Service
metadata:
  creationTimestamp: null
  name: destination
  namespace: trouble06
spec:
  ports:
  - port: 80
    protocol: TCP
    targetPort: 80
  selector:
    app: destination
  type: LoadBalancer
status:
  loadBalancer: {}
EOF

kubectl apply -f /home/student/srv-trouble06.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/deploy-trouble07.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  creationTimestamp: null
  labels:
    app: destination
  name: destination
  namespace: trouble07
spec:
  replicas: 1
  selector:
    matchLabels:
      app: destination
  strategy: {}
  template:
    metadata:
      creationTimestamp: null
      labels:
        app: destination
    spec:
      containers:
      - image: r.deso.tech/whoami/whoami:latest
        name: whoami
        resources: {}
status: {}
EOF

kubectl apply -f /home/student/deploy-trouble07.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/srv-trouble07.yaml
apiVersion: v1
kind: Service
metadata:
  creationTimestamp: null
  labels:
    app: destination
  name: destination
  namespace: trouble07
spec:
  ports:
  - port: 80
    protocol: TCP
    targetPort: 80
  selector:
    app: destination
  type: LoadBalancer
status:
  loadBalancer: {}
EOF

kubectl apply -f /home/student/srv-trouble07.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/policy-trouble07.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: policy-origin-destination
  namespace: trouble07
spec:
  podSelector: {}
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: origin
EOF

kubectl apply -f /home/student/policy-trouble07.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/origin-trouble07.yaml
apiVersion: v1
kind: Pod
metadata:
  name: origin
  namespace: trouble07
  labels:
    app: origin
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: origin
  restartPolicy: Always
EOF

kubectl apply -f /home/student/origin-trouble07.yaml >> $LOGFILE 2>&1

cat >> $LOGFILE 2>&1 <<EOF >>/home/student/origin2-trouble07.yaml
apiVersion: v1
kind: Pod
metadata:
  name: origin2
  namespace: trouble07
  labels:
    app: origine
spec:
  containers:
  - image: r.deso.tech/dsk/dsutils
    command:
      - sleep
      - "3600"
    imagePullPolicy: IfNotPresent
    name: origin2
  restartPolicy: Always
EOF

kubectl apply -f /home/student/origin2-trouble07.yaml >> $LOGFILE 2>&1